// setup categories button
require( './categories.js' )();
